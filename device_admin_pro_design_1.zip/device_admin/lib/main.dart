import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Privacy Guard',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: Colors.blueAccent,
        scaffoldBackgroundColor: const Color(0xFF121212),
        useMaterial3: true,
      ),
      home: const DeviceControlScreen(),
    );
  }
}

class DeviceControlScreen extends StatefulWidget {
  const DeviceControlScreen({super.key});

  @override
  State<DeviceControlScreen> createState() => _DeviceControlScreenState();
}

class _DeviceControlScreenState extends State<DeviceControlScreen> {
  static const platform = MethodChannel('com.example.device_admin/control');
  bool _isLocked = false;

  Future<void> _toggleLock(bool lock) async {
    try {
      await platform.invokeMethod('toggleLock', {"lock": lock});
      setState(() {
        _isLocked = lock;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(lock ? "Privacy Guard: LOCKED" : "Privacy Guard: UNLOCKED"),
          backgroundColor: lock ? Colors.redAccent : Colors.greenAccent,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } on PlatformException catch (e) {
      debugPrint("Error: ${e.message}");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: _isLocked 
              ? [const Color(0xFF2C0000), const Color(0xFF121212)]
              : [const Color(0xFF002C00), const Color(0xFF121212)],
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                _isLocked ? Icons.security : Icons.security_outlined,
                size: 100,
                color: _isLocked ? Colors.redAccent : Colors.greenAccent,
              ),
              const SizedBox(height: 20),
              Text(
                _isLocked ? "SYSTEM LOCKED" : "SYSTEM SECURE",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: _isLocked ? Colors.redAccent : Colors.greenAccent,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                "Camera, Mic & Location Control",
                style: TextStyle(color: Colors.white70, fontSize: 16),
              ),
              const SizedBox(height: 60),
              _buildActionButton(
                title: "LOCK SYSTEM",
                icon: Icons.lock,
                color: Colors.redAccent,
                onPressed: () => _toggleLock(true),
                isActive: _isLocked,
              ),
              const SizedBox(height: 20),
              _buildActionButton(
                title: "UNLOCK SYSTEM",
                icon: Icons.lock_open,
                color: Colors.greenAccent,
                onPressed: () => _toggleLock(false),
                isActive: !_isLocked,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onPressed,
    required bool isActive,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: 280,
      height: 60,
      child: ElevatedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, color: Colors.white),
        label: Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: isActive ? color : color.withOpacity(0.3),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
            side: BorderSide(color: color, width: 2),
          ),
          elevation: isActive ? 10 : 0,
        ),
      ),
    );
  }
}
