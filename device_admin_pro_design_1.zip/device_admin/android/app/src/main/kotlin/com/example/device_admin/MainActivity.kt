package com.example.device_admin

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.UserManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.example.device_admin/control"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "toggleLock") {
                val lock = call.argument<Boolean>("lock") ?: false
                val success = toggleDeviceFeatures(lock)
                if (success) {
                    result.success(null)
                } else {
                    result.error("UNAVAILABLE", "Could not change status. Make sure app is Device Owner.", null)
                }
            } else {
                result.notImplemented()
            }
        }
    }

    private fun toggleDeviceFeatures(lock: Boolean): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminComponent = ComponentName(this, AdminReceiver::class.java)

        // Check if Admin is active
        if (!dpm.isAdminActive(adminComponent)) {
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
            startActivity(intent)
            return false
        }

        return try {
            // 1. Disable Camera (Works with Device Admin)
            dpm.setCameraDisabled(adminComponent, lock)

            // 2. Disable Microphone & Location (Requires Device Owner)
            if (dpm.isDeviceOwnerApp(packageName)) {
                if (lock) {
                    // Disable Microphone
                    dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_UNMUTE_DEVICE)
                    dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_ADJUST_VOLUME)
                    
                    // Disable Location
                    dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_SHARE_LOCATION)
                    dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_CONFIG_LOCATION)
                } else {
                    // Re-enable Microphone
                    dpm.clearUserRestriction(adminComponent, UserManager.DISALLOW_UNMUTE_DEVICE)
                    dpm.clearUserRestriction(adminComponent, UserManager.DISALLOW_ADJUST_VOLUME)
                    
                    // Re-enable Location
                    dpm.clearUserRestriction(adminComponent, UserManager.DISALLOW_SHARE_LOCATION)
                    dpm.clearUserRestriction(adminComponent, UserManager.DISALLOW_CONFIG_LOCATION)
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
